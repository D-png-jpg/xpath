''' 创建名为linhuiyin的爬虫  并限定爬取域的范围
scrapy genspider linhuiyin "baike.baidu.com"
'''
import os
import scrapy
import re
from urllib.request import urlopen
from bs4 import BeautifulSoup
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import  CrawlSpider,Rule
from homework.items import HomeworkItem
#全局取消证书验证
import ssl
from scrapy.spiders import Rule, CrawlSpider

ssl._create_default_https_context = ssl._create_unverified_context


class LinhuiyinSpider(CrawlSpider):
    name = 'linhuiyin'       #爬虫的识别名称
    allowed_domains = ['baike.baidu.com']       #规定爬虫只爬取这个域名下的网页，不存在的URL会被忽略
    start_urls = ['https://baike.baidu.com/item/%E6%9E%97%E5%BE%BD%E5%9B%A0/236792']

    # # LinkExtractor提取链接
    # rules = (
    #     Rule(LinkExtractor(allow='https://baike.baidu.com/item/.+/\d+',
    #                        restrict_xpaths='//*[@class="lemma-relation-item"]'), follow=True, callback="parse1", ),
    #     Rule(LinkExtractor(allow='https://baike.baidu.com/pic/.+', restrict_xpaths='//*[@class="summary-pic"]'),
    #          follow=True, callback="parse2"),
    # )
    URLset = set()
    URLset.add("https://baide.baidu.com/item/林徽因/236792")

    # 解析内容函数
    def parse(self, response, Que=None):
        myurl = response.url
        pos = myurl.find("?")
        if pos > 0:
            myurl = myurl[:pos]  # 切片

        if myurl in LinhuiyinSpider.URLset:
            return
        LinhuiyinSpider.URLset.add(myurl)

        item = HomeworkItem()

        bs = BeautifulSoup(response.body,'html.parser')
        mytitle = bs.find('title')
        if mytitle is not None:
            arr = re.split('[^\u4e00-\u9fa5]',mytitle.get_text())
            item['name'] = arr[0]
            item['url'] = myurl
            for link in bs.find_all('a',{'href':re.compile('^/item/.*/\d+$')}):
                myspan = link.find('span',{'class':'title'})
                if myspan is not None:
                    new_url = 'https://baike.baidu.com'+link['href']
                    yield scrapy.Request(new_url)
                else: item['name'] = "None"


            # 人物生平
            meta = bs.find("meta",{'name':'description'})
            item['descrip'] = meta['content']
            #抓取并保存人物图像图片
            facediv = bs.find("div",{'class':"summary-pis"})
            if facediv is not None:
                faceimg = facediv.find('img',{"src":True})  #确定照片存在
                facesrc = urlopen(faceimg["src"])           #用链接来抓取图片
                item['portrail'] = facesrc.read()
            else: item['portrail'] = None


            relationdict = dict()  #创建人物关系字典
            for link in bs.find_all('a',{'href':re.compile('^/item/.*/\d+$')}):
                myspan = link.find('span',{'class':'title'})    #获取内链的人名
                if myspan is not None:
                    new_name = myspan.get_text()

                    myspan2 = link.find('span',{'class':'name'})  #获取内链的与当前人物的关系
                    relation = myspan2.get_text()                 # 关系文字
                    if relation not in relationdict:              #此关系不在字典中
                        relationdict[relation] = new_name         #设置关系和人名

            item['relation'] = relationdict

            yield item

    # def parse2(self, response):
    #     item = HomeworkItem()
    #     imglist = []
    #     bs = BeautifulSoup(response.body, "html.parser")
    #     mytitle = bs.find("title")
    #     arr = re.split('[^\u4e00-\u9fa5]', mytitle.get_text())
    #     item['name'] = arr[0][:-2]
    #     print(item['name'])
    #     list2 = bs.find_all('a', {'data-index': True})
    #     for a in list2:
    #         for myimg in a.find_all('img'):
    #             imgurl = myimg['src'].split('?')[0]
    #             print(imgurl)
    #             facesrc = urlopen(imgurl)
    #             imglist.append(facesrc.read())
    #     item['portrail'] = imglist
    #     yield item


'''
cd homework
cd homework
cd spiders
scrapy runspider linhuiyin.py'''
