# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
import os
import pickle

from itemadapter import ItemAdapter


class HomeworkPipeline:

    def process_item(self, item, spider):
        d=dict(item)

        if not os.path.exists(d['name']):
            print("File Not exist!")
            os.makedirs(d['name'])

        txtpath = d['name'] + '/' +d['name'] + ".txt"
        f = open(txtpath,"wb")
        f.write(d["name"])
        f.write(d["relation"])
        f.close()

        imgpath = d['name'] + '/' + d['name'] + ".jpg"
        f = open(imgpath,"wb")
        f.write(d["img"])
        f.close()

        return item

    # def process_item(self, item, spider):
    #     d = dict(item)  # 转成dict
    #
    #     #创建文件夹
    #     if not os.path.exists("d['name']"):      #文件夹名为人名
    #         os.makedirs("d['name']")
    #
    #     #文本文件
    #     txt_path ="d['name']"+ '/' + d['name'] + ".txt"      #路径
    #     f = open(txt_path, "wb")               #"w"是覆盖写，不要用”a“追加写 b是指二进制写法
    #     f.write(d["name"])               #把人名写进文本文件
    #     f.write(d["descrip"].encode())       #把人物生平写进文本文件
    #     f.write(d["relation"])                  #把人物关系写进文本文件
    #     f.close()
    #
    #     #图片
    #     imgpath = "E://d['name']"+ '/' + d['name'] + ".jpg"#路径
    #     f = open(imgpath, "wb")
    #     f.write(d["imgList"])
    #     f.close()
    #
    #     return item



    # def __init__(self):
    #     if not os.path.exists("d://linhuiyin"):
    #         os.makedirs("d://linhuiyin")
    # #
    # def process_item(self, item, spider):
    #     d = dict(item)
    #     if not os.path.exists("d://linhuiyin" + d['name']):
    #         os.makedirs("d://linhuiyin" + d['name'])  # 以人名新建文件夹
    #
    #     if "descrip" in d:
    #         txtpath = "d://linhuiyin" + d['name'] + '/' + d['name'] + ".txt"
    #         f = open(txtpath, "wb")
    #         f.write(d['descrip'].encode())
    #         f.close()
    #
    #     if "relation" in d:
    #         datgpath = "d://linhuiyin" + d['name'] + '/' + d['name'] + ".dat"
    #         output = open(datgpath, "wb")
    #         pickle.dump(dict(d['relation']), output)
    #         output.close()
    #
    #     if "portrail" in d:
    #         index = 0
    #         for img in d['portrail']:
    #             imgpath = "d://linhuiyin" + d['name'] + '/' + d['name'] + str(index) + ".png"
    #             f = open(imgpath, "wb")
    #             f.write(img)
    #             f.close()
    #             index += 1
    #
    #     return item


