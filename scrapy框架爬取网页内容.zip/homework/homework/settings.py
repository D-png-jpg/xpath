BOT_NAME = 'homework'

SPIDER_MODULES = ['homework.spiders']
NEWSPIDER_MODULE = 'homework.spiders'

# 禁止cookies,防止被ban
COOKIES_ENABLED = False
COOKIES_ENABLES = False

# 设置Pipeline,此处实现数据写入文件
ITEM_PIPELINES = {
    'homework.pipelines.HomeworkPipeline': 30
}

# 设置爬虫爬取的最大深度
DEPTH_LIMIT = 10

CLOSESPIDER_PAGECOUNT = 50
CLOSESPIDER_ITEMCOUNT = 200